﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Programming3_assignments
{
    enum Lane
    {
        Left,Center,Right
    }
}
