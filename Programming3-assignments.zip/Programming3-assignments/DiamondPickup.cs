﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Programming3_assignments
{
    class DiamondPickup : ScorePickup
    {
        public DiamondPickup(float progression, Lane lane, int score) : base(progression, lane, score)
        {

        }
    }
}
