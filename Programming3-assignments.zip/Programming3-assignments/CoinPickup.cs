﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Programming3_assignments
{
    class CoinPickup : ScorePickup
    {
        public CoinPickup(float progression, Lane lane, int score) : base(progression, lane, score)
        {

        }
    }
}
