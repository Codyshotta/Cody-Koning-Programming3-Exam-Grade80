﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Programming3_assignments
{
    class SpeedBoostPickup : Pickup
    {
        public SpeedBoostPickup(float progression, Lane lane) : base(progression, lane)
        {

        }
    }
}
